=============================
Google Mobile Ads SDK for iOS
=============================

This is the Google Mobile Ads SDK for iOS.

Requirements:
- An AdMob site ID or DoubleClick for Publishers account.
- Xcode 5.1 or later.
- Runtime of iOS 5.0 or later.

The latest documentation and code samples are available at:
https://developers.google.com/mobile-ads-sdk/docs/
